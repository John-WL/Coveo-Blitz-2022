package codes.blitz.game.totem_utils;

public class Shape {

}
