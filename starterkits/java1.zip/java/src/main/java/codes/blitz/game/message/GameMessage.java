package codes.blitz.game.message;

public record GameMessage(int tick, Question payload) {
}
