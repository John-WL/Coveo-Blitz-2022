package codes.blitz.game.message;

public enum Totem {
    I,
    O,
    J,
    L,
    S,
    Z,
    T,
    MIXED
}
