package codes.blitz.game.message;

import java.util.List;

public record TotemAnswer(Totem shape, List<CoordinatePair> coordinates) {

}
