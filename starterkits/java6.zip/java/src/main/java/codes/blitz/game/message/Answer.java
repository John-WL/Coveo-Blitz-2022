package codes.blitz.game.message;

import java.util.List;

public record Answer(List<TotemAnswer> totems) {
}
