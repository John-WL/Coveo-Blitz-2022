package codes.blitz.game.message;

import java.util.List;

public record Question(List<TotemQuestion> totems) {
}

