package codes.blitz.game.message;

public record TotemQuestion(Totem shape) {
}
